from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from app725 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('app725.urls')), 
    path('registration/', views.registration, name='registration'),
    path('', TemplateView.as_view(template_name='index.html'), name='index'),
]

