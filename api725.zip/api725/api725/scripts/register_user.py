import requests
import json

# URL сервера
url = 'http://127.0.0.1:8080/registration/'

# Данные для регистрации пользователя
data = {
    'email': 'example@example.com',
    'password': 'your_password_here',
    'role': 'admin'  # Здесь укажите роль пользователя, 'admin' или 'user'
}

response = requests.post(url, data=json.dumps(data))

print(response.json())
