from django.http import HttpResponse
from openpyxl import Workbook
from .models import rooms

def get_xlsx(request):
    wb = Workbook()
    ws = wb.active

    rooms_data = rooms.objects.all()


    ws.append(['roomsId', 'number_of_room', 'type_of_room'])
    for room in rooms_data:
        ws.append([room.roomsId, room.number_of_room, room.type_of_room])


    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=rooms.xlsx'
    wb.save(response)

    return response
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.contrib.auth.models import User
from .models import Role 

@csrf_exempt
def registration(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            email = data['email']
            password = data['password']
            role_name = data['role']  

            # Создание пользователя
            user = User.objects.create_user(email, email, password)
            role, created = Role.objects.get_or_create(name=role_name)
            user.role = role
            user.save()

            return JsonResponse({'message': 'User registered successfully'})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    else:
        return JsonResponse({'error': 'Only POST method allowed. To register in system pls use file <register_user.py>'}, status=405)
