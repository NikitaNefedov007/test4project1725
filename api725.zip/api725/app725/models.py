from django.db import models

class rooms(models.Model):
    roomsId = models.AutoField(primary_key=True)
    number_of_room = models.IntegerField()
    type_of_room = models.CharField(max_length=50)

class Role(models.Model):
    name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name

class users(models.Model):
    usersId = models.AutoField(primary_key=True)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)

    def __str__(self):
        return self.email
