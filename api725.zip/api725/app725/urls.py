from django.urls import path
from .views import get_xlsx

urlpatterns = [
    path('unload/get_xlsx', get_xlsx, name='get_xlsx'),
]



